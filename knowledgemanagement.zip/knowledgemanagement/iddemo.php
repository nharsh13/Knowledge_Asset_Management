<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width = device-width, initial-scale = 1, shrink-to-fit = no">
    <link rel="stylesheet" href="Reg.css">
    <title>Cloud Conversion Registration Form</title>
    <style>
        .note {
            text-align: center;
            height: 100px;
            background: -webkit-linear-gradient(left, #0072ff, #8811c5);
            color: #fff;
            font-weight: bold;
            line-height: 10px;
        }

        body {
            /* padding-top: 50px; */
            margin: 0;
            font-family: 'Lato', sans-serif;
            font-size: 12px;
            line-height: 1.8em;
            text-transform: none;
            letter-spacing: .075em;
            font-weight: bold;
            font-style: normal;
            text-decoration: none;
            color: #e7bd74;
            background-color: rgba(249 249 249);
            display: block;
        }

        .title {
            margin-top: 2rem;
            margin-bottom: 1rem;
        }

        .form-content {
            padding: 5%;
            border: 1px solid #ced4da;
            margin-bottom: 2%;
        }

        .form-control {
            border-radius: 1.5rem;
            display: block;
            width: 100%;
            height: calc(2.25rem + 5px);
            padding: .375rem .75rem;
            font-size: 1rem;
            line-height: 1.5;
            color: #495057;
            background-color: #e7decc;
            ;
            background-clip: padding-box;
            border: 1px solid #ced4da;
        }

        .btnSubmit {
            border: none;
            border-radius: 1.5rem;
            padding: 1%;
            width: 20%;
            cursor: pointer;
            background: #0062cc;
            color: #fff;
        }

        h1 {
            font-family: sans-serif;
            display: block;
            font-size: 1rem;
            font-weight: bold;
            text-align: center;
            letter-spacing: 3px;
            color: hotpink;
            text-transform: uppercase;
            padding-top: 35px;
        }

        a {
            text-decoration: none;
            color: black;
        }

        a:hover {
            text-decoration: none;
            color: #496583;
        }

        input:invalid {
            background-color: white;
            border-color: red;
        }
    </style>
</head>

<body>


    <div class="container register-form">
        <form class="form" action="Reg_Control.php" method="post">
            <div class="note">
                <h1> Asset Management Admin Registration Form. </h1>
            </div>
            <div class="form-content">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <input type="name" class="form-control" placeholder="User Name *" value=""
                                name="Username" />
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="User Full Name*" value=""
                                name="fullname" />
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <input type="password" class="form-control" placeholder="Your Password *" value=""
                                name="password" />
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control" placeholder="Confirm Password *" value=""
                                name="CPassword" />
                        </div>
                    </div>

                </div>

                <div class="row align-items-center mt-4">
                    <div class="col">
                        <input type="Email" class="form-control"
                            placeholder=" Email Id(Ex-ab123456.ttl@tatamotors.com)*" name="EmailId">
                    </div>
                </div>
                <div class="row align-items-center mt-4">
                    <div class="col">
                        <input type="text" class="form-control" placeholder="Phone Number *" name="PhoneNumber">
                    </div>
                </div>


                <div class="row justify-content-start mt-4">
                    <div class="col">

                        <button type="submit" class="btnSubmit" name="submit" id="submit"> Submit </button>
                    </div>
                </div>
            </div>
        </form>
       

    </div>

</body>

</html>