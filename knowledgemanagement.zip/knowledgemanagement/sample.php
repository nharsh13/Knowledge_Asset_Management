<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Delete Rows</title>
<style>
    table {
        border-collapse: collapse;
        width: 100%;
    }
    th, td {
        border: 1px solid black;
        padding: 8px;
        text-align: center;
    }
    button {
        background-color: red;
        color: white;
        border: none;
        padding: 5px 10px;
        cursor: pointer;
    }
</style>
</head>
<body>
    <table id="data-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Category</th>
                <th>User</th>
                <th>Upload Date</th>
                <th>Download</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
      
            <?php
            include 'Config.php';
            error_reporting(0);
            $query = "SELECT * FROM document ORDER BY UploadDate DESC limit $start ,$per_page  ";
            $data = mysqli_query($conn, $query);
            $total = mysqli_num_rows($data);
            
            if ($total > 0) {
                while ($result = mysqli_fetch_assoc($data)) {
                   $link = $result['File_Loc'];
                   $documentId = $result['DocumentID'];
                  
                    ?>
                    <tr>
                        <td><?php echo $documentId ?></td>
                        <td><?php echo $result['DocumentName'] ?></td>
                        <td><?php echo $result['Category'] ?></td>
                        <td><?php echo $result['UserName'] ?></td>
                        <td><?php echo $result['UploadDate'] ?></td>
                        <td><a href="<?php echo $link;?>" download>Download file</a></td>
                        <td><button onclick="deleteRow(<?php echo $documentId; ?>)">Delete</button></td>
                    </tr>
                    <?php
                }
            }
            ?>

        </tbody>       
    </table>

    <script>
        function deleteRow(rowId) {
            if (confirm("Are you sure you want to delete this row?")) {
                const table = document.getElementById("data-table");
                const rowIndex = Array.from(table.rows).findIndex(row => row.cells[0].textContent == rowId);
                table.deleteRow(rowIndex);
                
                // Send an AJAX request to delete the row from the database
                const xhr = new XMLHttpRequest();
                xhr.open("POST", "delete_row.php", true);
                xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === 4 && xhr.status === 200) {
                        console.log(xhr.responseText); // Log server response
                    }
                };
                xhr.send("row_id=" + rowId);
            }
        }
    </script>
</body>
</html>
