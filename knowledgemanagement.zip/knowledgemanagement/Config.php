<?php
$conn = mysqli_connect("localhost", "root", "", "knowledgemanagement") or die("Connection Failed");

?>